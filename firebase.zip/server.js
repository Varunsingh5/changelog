const express = require("express")
var cors = require('cors')
const sendMail = require("./mailSend");
var bodyParser = require('body-parser');
var app = express();

const corsOptions = {
    origin: '*',
    methods: ['POST', 'GET', 'PATCH', 'DELETE', 'OPTIONS'],
    credentials: true,
    allowedHeaders: ['Content-type','Authorization','Origin','Access-Control-Allow-Origin','Accept','Options','X-Requested-With']
}
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors(corsOptions));


app.post("/send_mail",function(request,response){
    console.log("request=====>>>>",request.body);
    sendMail(request.body?.email,`http://localhost:3000/user/login?phone=${request.body?.phone}`)
response.send("Hello World!")
})
app.listen(3005, function () {
console.log("Started application on port %d", 3005)
});