import React from 'react'

const userForm = () => {
  return (
    <div>

        
<form>
    <div>
        <label>About me:</label>
        <input type="text" />

    </div>

    <div>
        <h3>Skills</h3>
        <div>
        <label>Programming:</label>
        <input type="text" />

        <label>Web & Scripting:</label>
        <input type="text" />

        <label>Database:</label>
        <input type="text" />

        <label>Tools:</label>
        <input type="text" />
        </div>
      
        
    </div>

  



    <div>
        <h3>Office Contact</h3>
        <div>
        <label>Phone No.::</label>
        <input type="number" />

        <label>Email:</label>
        <input type="text" />

        <label>Skype:</label>
        <input type="text" />

        <label>LinkedIn:</label>
        <input type="text" />
        </div>
      
        
    </div>



    
    <div>
        <h3> Current Address</h3>
        <div>
        <label> House No./Flat No.:</label>
        <input type="number" />

        <label>Vill./Area/Block:</label>
        <input type="text" />

        <label>Landmarks:</label>
        <input type="text" />

        <label>City:</label>
        <input type="text" />

        
        <label>State:</label>
        <input type="text" />


        
        <label>PinCode:</label>
        <input type="text" />

        <label>Country:</label>
        <input type="text" />
        </div>
      
        
    </div>


    <div>
        <h3> Permanent Address</h3>
        <div>
        <label> House No./Flat No.:</label>
        <input type="number" />

        <label>Vill./Area/Block:</label>
        <input type="text" />

        <label>Landmarks:</label>
        <input type="text" />

        <label>City:</label>
        <input type="text" />

        
        <label>State:</label>
        <input type="text" />


        
        <label>PinCode:</label>
        <input type="text" />

        <label>Country:</label>
        <input type="text" />
        </div>
      
        
    </div>


    <div>
        <h3> Identification Details</h3>
        <div>
        <label> Adhaar Card:</label>
        <input type="number" />

        <label>PanCard</label>
        <input type="text" />

        <label>VoterCard:</label>
        <input type="text" />

        <label>Passport No.:</label>
        <input type="text" />

        
        <label>Driving License:</label>
        <input type="text" />


        
        <label>Vehicle Regd No.:</label>
        <input type="text" />


        </div>


        
    <div>
        <h3>  Personal Details</h3>
        <div>
        <label>  Father's Name::</label>
        <input type="text" />

        <label>Mother's Name:</label>
        <input type="text" />

        <label>Marital Status:</label>
        <input type="text" />

        <label>D.O.B: </label>
        <input type="text" />

        
        <label> Hobbies:</label>
        <input type="text" />


        
        <label>Blood Group:</label>
        <input type="text" />

        <label>Nationality:</label>
        <input type="text" />
        

        </div>


        <div>
        <h3>  Educational Details</h3>
        <div>
        <label> Qualification</label>
        <input type="text" />

        <label>Stream:</label>
        <input type="text" />

        <label>Session :</label>
        <input type="text" />

        <label>Year of Passing:
</label>
        <input type="text" />

        

        </div>
      
        
    </div>



</form>


    </div>
  )
}

export default userForm