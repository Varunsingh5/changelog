const hasToken = (token) => {
  console.log("token",token);
  if (token) {
    return true
  }
}

export default hasToken;
